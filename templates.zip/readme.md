﻿Wildpflanzen
============

Static web site generator for image photograps


[Wildpflanzen. Webpage hosted in GitHub](https://picuino.github.io/wildpflanzen/index.html)


[Original Wildpflanzen Web](http://www.wildpflanzen.com.de/)


Licenses
========

[Contents under Creative Commons Attribution-NonCommercial-ShareAlike
3.0 Unported License](https://creativecommons.org/licenses/by-nc-sa/3.0/)


[Computer programs under GPL v3.0 License](https://www.gnu.org/licenses/gpl-3.0.en.html)
