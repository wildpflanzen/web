import os
import re
import codecs
from jinja2 import Environment, FileSystemLoader, Template
import yaml
import subprocess
import shutil
from collections import UserDict


def main():
   database = Database()
   database.read('../../source')


# --------------------------------------------------------------------
#    DATABASE CLASS
# --------------------------------------------------------------------

class Database(UserDict):

   def __init__(self):
      UserDict.__init__(self) 
      self['groups'] = {}
      self['species'] = []
      self.filenames = []


   def read(self, path):
      self.read_paths(path)
      

   def read_paths(self, path):
      # Process files
      fnames = [f.lower() for f in os.listdir(path)]
      if 'index.txt' in fnames:
         self.parse_file(path, 'index.txt')

      # Recurse subdirs
      for f in fnames:
         fullname = os.path.join(path, f)
         if os.path.isdir(fullname):
            self.read_paths(fullname)


   def parse_file(self, path, fname):
      print(path, fname)
      # Read yaml documents from file
      with codecs.open(os.path.join(path, fname), 'r', encoding='utf-8-sig') as fi:
         data = fi.read()

      data_fields = data.split('\n')
      print(data_fields)
      input()



   def add_group(self):
      # Generate group unique name
      self.file_name()

      # Add group species list
      self.register['species'] = []

      # Store register in database
      self['groups'][self.register['path']] = self.register


   def file_name(self):
      # Generate register name
      if 'genus' in self.register and 'species' in self.register:
         name = self.register['genus'] + '-' + self.register['species']
      else:
         name = '-'.join(self.register['splitpath'])

      # Normalize filename
      name = re.sub('[^a-zA-Z0-9]', '-', name).lower()
      name = re.sub('-+', '-', name)
      name = re.sub('-^', '', name).lower()

      # Test if duplicated
      if name in self.filenames:
         print('   Error, duplicated name: %s' % name)
      else:
         self.filenames.append(name)

      # Store filename
      self.register['filename'] = name


   def test_errors(self):
      print('\nFinding errors ...')

      # Test all species
      for register in self['species']:
         # Test if database images exists
         images = []
         for session in register['sessions']:
            for image in session['images']:
               if self.test_file(register['path'], image):
                  images.append(image)
         if 'thumb' in register and not register['thumb'] in images:
            if self.test_file(register['path'], register['thumb']):
               images.append(register['thumb'])
         else:
            register['thumb'] = images[0]

         # Test if image files are in database
         for file in os.listdir(register['path']):
            if file[-4:].lower() == '.jpg' and file not in images:
                  print('   Error, not in database: %s' % os.path.join(register['path'], file))

         # Link species with group
         group_path = register['group_path']
         if not group_path in self['groups']:
            print('   species without group: %s' % register['path'])
            continue
         group = self['groups'][group_path]
         if not register in group['species']:
             group['species'].append(register)
             register['group'] = group
         else:
            print('   duplicated species: %s' % group_path)

      # Delete empty groups
      clean_groups = {}
      for key, group in self['groups'].items():
         if group['species']:
            clean_groups[key] = group
      self['groups'] = clean_groups

      # Sort groups and link in chain
      keys = [k for k in self['groups'].keys()]
      keys.sort()
      for i in range(len(keys)-1):
         self['groups'][keys[i]]['group_next'] = self['groups'][keys[i+1]]
         self['groups'][keys[i]]['group_prev'] = self['groups'][keys[i-1]]
      self['groups'][keys[-1]]['group_next'] = self['groups'][keys[0]]
      self['groups'][keys[-1]]['group_prev'] = self['groups'][keys[-2]]

      # Sort species and link in chain
      all_species = []
      for key in keys:
         species = [s for s in self['groups'][key]['species']]
         species.sort(key=lambda s: s['filename'])
         all_species = all_species + species

      for i in range(len(all_species)-1):
         all_species[i]['species_next'] = all_species[i+1]
         all_species[i]['species_prev'] = all_species[i-1]
      all_species[-1]['species_next'] = all_species[0]
      all_species[-1]['species_prev'] = all_species[-2]


   # Test if file exists
   def test_file(self, path, file):
      filename = os.path.join(path, file)
      if not os.path.isfile(filename):
         print("   Error, file doesn't exitst: %s" % filename)
         return None
      return filename


main()
